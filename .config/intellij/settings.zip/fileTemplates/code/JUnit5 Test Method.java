@org.junit.jupiter.api.Test
void ${NAME}() {
    // Given
    
    // When
    
    // Then
    //assertThat().isTrue();
  ${BODY}
}