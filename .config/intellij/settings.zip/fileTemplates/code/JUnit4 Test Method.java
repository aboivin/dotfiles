@org.junit.Test
public void should_do_smthg() throws Exception {
  // Given
  
  // When
  ${BODY}
  // Then
}